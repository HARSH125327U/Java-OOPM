package Controller;
import Model.Model;
import Model.Users.Users;
import View.View;

import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;

public class Controller {
    Model model;
    View view;
    public Controller(Model m,View v){
        model = m;
        view = v;
        view.getFf().getManageSoftwareBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Software Button Clicked");
                view.getFf().setVisible(false);
                view.getMsof().setVisible(true);
            }
        });
        view.getMsof().addWindowListener(new java.awt.event.WindowAdapter(){
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                view.getFf().setVisible(true);
            }
        });

        model.getMa().setLinesBeingDisplayed(20);
        view.centerInitialSetupSoftware(model.getMa().getLinesBeingDisplayed(),model.getMa().getHeaders().size());

        model.getMa().setFirstLineToDisplay(20);
        view.centerUpdateSoftware(model.getMa().getLines(model.getMa().getFirstLineToDisplay(),model.getMa().getLastLineToDisplay()),model.getMa().getHeaders());

        view.getMsof().getSoftware_ip().getStp().addMouseWheelListener(new MouseWheelListener() {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e) {
                int units = e.getUnitsToScroll();
                System.out.println(units);
                int current_first_line = model.getMa().getFirstLineToDisplay();
                int current_last_line = model.getMa().getLastLineToDisplay();
                int no_of_courses = model.getMa().getTable().size();
                int no_of_display_lines = model.getMa().getLinesBeingDisplayed();
                if(units <= 0 && current_first_line == 0)
                {
                    model.getMa().setFirstLineToDisplay(0);
                }
                else if(units <= 0 && current_first_line > 0)
                {
                    int new_first_line = current_first_line + units;
                    if(new_first_line <= 0)
                    {
                        model.getMa().setFirstLineToDisplay(0);
                    }
                    else
                    {
                        model.getMa().setFirstLineToDisplay(new_first_line);
                    }
                }
                else if(units > 0 && current_last_line == no_of_courses-1)
                {
                    model.getMa().setFirstLineToDisplay(current_first_line);
                }
                else if (units > 0 && current_last_line < no_of_courses-1)
                {
                    int new_first_line = current_first_line + units;
                    if(new_first_line > no_of_courses - no_of_display_lines)
                    {
                        new_first_line = no_of_courses-no_of_display_lines;
                        model.getMa().setFirstLineToDisplay(new_first_line);
                    }
                    else
                    {
                        model.getMa().setFirstLineToDisplay(new_first_line);
                    }
                }

                view.centerUpdateSoftware(model.getMa().getLines(model.getMa().getFirstLineToDisplay(), model.getMa().getLastLineToDisplay()), model.getMa().getHeaders());
            }
        });

        view.getMsof().getSoftware_ip().getAsp().getAddSoftwareBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String txt_software_id = view.getMsof().getSoftware_ip().getAsp().getTxt_software_id().getText();
                String txt_software_name = view.getMsof().getSoftware_ip().getAsp().getTxt_software_name().getText();
                String txt_software_size = view.getMsof().getSoftware_ip().getAsp().getTxt_software_size().getText();
                String txt_application_id = view.getMsof().getSoftware_ip().getAsp().getTxt_application_id().getText();
                String txt_application_name = view.getMsof().getSoftware_ip().getAsp().getTxt_application_name().getText();
                String txt_application_version = view.getMsof().getSoftware_ip().getAsp().getTxt_application_version().getText();
                String txt_application_release_date = view.getMsof().getSoftware_ip().getAsp().getTxt_application_release_date().getText();
                try {
                    model.getMa().addNewApplication(Integer.valueOf(txt_application_id),txt_application_name,txt_application_version,txt_application_release_date,Integer.valueOf(txt_software_id),txt_software_name,Integer.valueOf(txt_software_size));
                }catch (IOException ex){
                    throw new RuntimeException(ex);
                }
            }
        });

        view.getMsof().getSoftware_ip().getEsp().getGetSoftwareBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Get Software Details Clicked");
                String txt_software_idx = view.getMsof().getSoftware_ip().getEsp().getTxt_get_software_idx().getText();
                model.getMa().readAppJsonFile("src/Model/Softwares/Application_Data.json");
                int software_id = model.getMa().getTable().get(Integer.valueOf(txt_software_idx)).getSoftware_id();
                String software_name = model.getMa().getTable().get(Integer.valueOf(txt_software_idx)).getSoftware_name();
                int software_size = model.getMa().getTable().get(Integer.valueOf(txt_software_idx)).getSoftware_size();
                int application_id = model.getMa().getTable().get(Integer.valueOf(txt_software_idx)).getApp_id();
                String application_name = model.getMa().getTable().get(Integer.valueOf(txt_software_idx)).getApp_name();
                String application_version = model.getMa().getTable().get(Integer.valueOf(txt_software_idx)).getVersion();
                String application_release_date = model.getMa().getTable().get(Integer.valueOf(txt_software_idx)).getRelease_date();

                view.getMsof().getSoftware_ip().getEsp().getTxt_software_id().setText(String.valueOf(software_id));
                view.getMsof().getSoftware_ip().getEsp().getTxt_software_name().setText(software_name);
                view.getMsof().getSoftware_ip().getEsp().getTxt_software_size().setText(String.valueOf(software_size));
                view.getMsof().getSoftware_ip().getEsp().getTxt_application_id().setText(String.valueOf(application_id));
                view.getMsof().getSoftware_ip().getEsp().getTxt_application_name().setText(application_name);
                view.getMsof().getSoftware_ip().getEsp().getTxt_application_version().setText(application_version);
                view.getMsof().getSoftware_ip().getEsp().getTxt_application_release_date().setText(application_release_date);
            }
        });

        view.getMsof().getSoftware_ip().getEsp().getEditSoftwareBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Edit Software Button Clicked");
                String txt_software_idx = view.getMsof().getSoftware_ip().getEsp().getTxt_get_software_idx().getText();
                String txt_software_id = view.getMsof().getSoftware_ip().getEsp().getTxt_software_id().getText();
                String txt_software_name = view.getMsof().getSoftware_ip().getEsp().getName().toUpperCase();
                String txt_software_size = view.getMsof().getSoftware_ip().getEsp().getTxt_software_size().getText();
                String txt_application_idx = view.getMsof().getSoftware_ip().getEsp().getTxt_application_idx().getText();
                String txt_application_id = view.getMsof().getSoftware_ip().getEsp().getTxt_application_id().getText();
                String txt_application_name = view.getMsof().getSoftware_ip().getEsp().getTxt_application_name().getText();
                String txt_application_version = view.getMsof().getSoftware_ip().getEsp().getTxt_application_version().getText();
                String txt_application_release_date = view.getMsof().getSoftware_ip().getEsp().getTxt_application_release_date().getText();
                try {
                    model.getMa().editApplication(Integer.valueOf(txt_application_idx),Integer.valueOf(txt_software_idx),Integer.valueOf(txt_application_id),txt_application_name,txt_application_version,txt_application_release_date,Integer.valueOf(txt_software_id),txt_software_name,Integer.valueOf(txt_software_size));
                } catch (IOException ex){
                    throw new RuntimeException(ex);
                }

            }
        });

        view.getMsof().getSoftware_ip().getDsp().getDeleteSoftwareBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Delete Software Button Clicked");
                String txt_application_idx = view.getMsof().getSoftware_ip().getDsp().getTxt_del_application_id().getText();
                try {
                    int a_id = model.getMa().deleteApplication(Integer.valueOf(txt_application_idx));
                    for (int i=0;i<model.getMl().getTable().size();i++){
                        if (a_id == model.getMl().getTable().get(i).getA_temp().getApp_id()){
                            model.getMl().deleteLicense(i);
                        }
                    }
                } catch (IOException ex){
                    throw new RuntimeException(ex);
                }
            }
        });

        view.getFf().getManageUserBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("User Button Clicked");
                view.getFf().setVisible(false);
                view.getMuf().setVisible(true);
            }
        });
        view.getMuf().addWindowListener(new java.awt.event.WindowAdapter(){
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                view.getFf().setVisible(true);
            }
        });

        model.getMu().setLinesBeingDisplayed(20);
        view.centerInitialSetupUser(model.getMu().getLinesBeingDisplayed(),model.getMu().getHeaders().size());

        model.getMu().setFirstLineToDisplay(20);
        view.centerUpdateUser(model.getMu().getLines(model.getMu().getFirstLineToDisplay(),model.getMu().getLastLineToDisplay()),model.getMu().getHeaders());

        view.getMuf().getIu().getCpu().addMouseWheelListener(new MouseWheelListener() {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e) {
                int units = e.getUnitsToScroll();
                System.out.println(units);
                int current_first_line = model.getMu().getFirstLineToDisplay();
                int current_last_line = model.getMu().getLastLineToDisplay();
                int no_of_courses = model.getMu().getTable().size();
                int no_of_display_lines = model.getMu().getLinesBeingDisplayed();
                if(units <= 0 && current_first_line == 0)
                {
                    model.getMu().setFirstLineToDisplay(0);
                }
                else if(units <= 0 && current_first_line > 0)
                {
                    int new_first_line = current_first_line + units;
                    if(new_first_line <= 0)
                    {
                        model.getMu().setFirstLineToDisplay(0);
                    }
                    else
                    {
                        model.getMu().setFirstLineToDisplay(new_first_line);
                    }
                }
                else if(units > 0 && current_last_line == no_of_courses-1)
                {
                    model.getMu().setFirstLineToDisplay(current_first_line);
                }
                else if (units > 0 && current_last_line < no_of_courses-1)
                {
                    int new_first_line = current_first_line + units;
                    if(new_first_line > no_of_courses - no_of_display_lines)
                    {
                        new_first_line = no_of_courses-no_of_display_lines;
                        model.getMu().setFirstLineToDisplay(new_first_line);
                    }
                    else
                    {
                        model.getMu().setFirstLineToDisplay(new_first_line);
                    }
                }

                view.centerUpdateUser(model.getMu().getLines(model.getMu().getFirstLineToDisplay(), model.getMu().getLastLineToDisplay()), model.getMu().getHeaders());
            }
        });

        view.getMuf().getIu().getApu().getAddUserBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String txt_user_id = view.getMuf().getIu().getApu().getTxt_user_id().getText();
                String txt_user_rating = view.getMuf().getIu().getApu().getTxt_user_rating().getText();
                String txt_id = view.getMuf().getIu().getApu().getTxt_id().getText();
                String txt_Name = view.getMuf().getIu().getApu().getTxt_Name().getText();
                String txt_address = view.getMuf().getIu().getApu().getTxt_address().getText();
                String txt_mobile = view.getMuf().getIu().getApu().getTxt_mobile().getText();
                try {
                    model.getMu().addNewUser(txt_Name,txt_address,txt_mobile,Integer.valueOf(txt_id),Integer.valueOf(txt_user_id),Integer.valueOf(txt_user_rating));
                }catch (IOException ex){
                    throw new RuntimeException(ex);
                }
            }
        });

        view.getMuf().getIu().getEup().getGetUserBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Get User Details Clicked");
                String txt_user_idx = view.getMuf().getIu().getEup().getTxt_get_user_idx().getText();
                model.getMu().readUserJsonFile("src/Model/Users/User_Data.json");
                int user_id = model.getMu().getTable().get(Integer.valueOf(txt_user_idx)).getUser_id();
                int user_rating = model.getMu().getTable().get(Integer.valueOf(txt_user_idx)).getUser_rating();
                int id = model.getMu().getTable().get(Integer.valueOf(txt_user_idx)).getId();
                String Name = model.getMu().getTable().get(Integer.valueOf(txt_user_idx)).getName();
                String Address = model.getMu().getTable().get(Integer.valueOf(txt_user_idx)).getAddress();
                String mobile = model.getMu().getTable().get(Integer.valueOf(txt_user_idx)).getMobile();

                view.getMuf().getIu().getEup().getTxt_user_id().setText(String.valueOf(user_id));
                view.getMuf().getIu().getEup().getTxt_user_rating().setText(String.valueOf(user_rating));
                view.getMuf().getIu().getEup().getTxt_id().setText(String.valueOf(id));
                view.getMuf().getIu().getEup().getTxt_Name().setText(Name);
                view.getMuf().getIu().getEup().getTxt_address().setText(Address);
                view.getMuf().getIu().getEup().getTxt_mobile().setText(mobile);
            }
        });

        view.getMuf().getIu().getEup().getEditUserBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Edit User Button Clicked");
                String txt_user_idx = view.getMuf().getIu().getEup().getTxt_get_user_idx().getText();
                String txt_user_id = view.getMuf().getIu().getEup().getTxt_user_id().getText();
                String txt_user_rating = view.getMuf().getIu().getEup().getTxt_user_rating().getText();
                String txt_person_idx = view.getMuf().getIu().getEup().getTxt_person_idx().getText();
                String txt_id = view.getMuf().getIu().getEup().getTxt_id().getText();
                String txt_Name = view.getMuf().getIu().getEup().getTxt_Name().getText();
                String txt_address = view.getMuf().getIu().getEup().getTxt_address().getText();
                String txt_mobile = view.getMuf().getIu().getEup().getTxt_mobile().getText();
                try {
                    model.getMu().editUser(Integer.valueOf(txt_person_idx),Integer.valueOf(txt_user_idx),txt_Name,txt_address,txt_mobile,Integer.valueOf(txt_id),Integer.valueOf(txt_user_id),Integer.valueOf(txt_user_rating));
                } catch (IOException ex){
                    throw new RuntimeException(ex);
                }

            }
        });

        view.getMuf().getIu().getDup().getDeleteUserBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Delete Software Button Clicked");
                String txt_user_idx = view.getMuf().getIu().getDup().getTxt_del_user_id().getText();
                try {
                    int u_id = model.getMu().deleteUser(Integer.valueOf(txt_user_idx));
                    for (int i=0;i<model.getMl().getTable().size();i++){
                        if (u_id == model.getMl().getTable().get(i).getU_temp().getUser_id()){
                            model.getMl().deleteLicense(i);
                        }
                    }
                } catch (IOException ex){
                    throw new RuntimeException(ex);
                }
            }
        });
        view.getFf().getManageLicenseBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("License Button Clicked");
                view.getFf().setVisible(false);
                view.getMlf().setVisible(true);
            }
        });

        view.getMlf().addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                view.getFf().setVisible(true);
            }
        });

        model.getMl().setLinesBeingDisplayed(20);
        view.centerInitialSetupLicense(model.getMl().getLinesBeingDisplayed(),model.getMl().getHeaders().size());

        model.getMl().setFirstLineToDisplay(20);
        view.centerUpdateLicenses(model.getMl().getLines(model.getMl().getFirstLineToDisplay(),model.getMl().getLastLineToDisplay()),model.getMl().getHeaders());

        view.getMlf().getLicense_ip().getLtp().addMouseWheelListener(new MouseWheelListener() {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e) {
                int units = e.getUnitsToScroll();
                System.out.println(units);
                int current_first_line = model.getMl().getFirstLineToDisplay();
                int current_last_line = model.getMl().getLastLineToDisplay();
                int no_of_courses = model.getMl().getTable().size();
                int no_of_display_lines = model.getMl().getLinesBeingDisplayed();
                if(units <= 0 && current_first_line == 0)
                {
                    model.getMl().setFirstLineToDisplay(0);
                }
                else if(units <= 0 && current_first_line > 0)
                {
                    int new_first_line = current_first_line + units;
                    if(new_first_line <= 0)
                    {
                        model.getMl().setFirstLineToDisplay(0);
                    }
                    else
                    {
                        model.getMl().setFirstLineToDisplay(new_first_line);
                    }
                }
                else if(units > 0 && current_last_line == no_of_courses-1)
                {
                    model.getMl().setFirstLineToDisplay(current_first_line);
                }
                else if (units > 0 && current_last_line < no_of_courses-1)
                {
                    int new_first_line = current_first_line + units;
                    if(new_first_line > no_of_courses - no_of_display_lines)
                    {
                        new_first_line = no_of_courses-no_of_display_lines;
                        model.getMl().setFirstLineToDisplay(new_first_line);
                    }
                    else
                    {
                        model.getMl().setFirstLineToDisplay(new_first_line);
                    }
                }

                view.centerUpdateLicenses(model.getMl().getLines(model.getMl().getFirstLineToDisplay(), model.getMl().getLastLineToDisplay()), model.getMl().getHeaders());
            }
        });

        view.getMlf().getLicense_ip().getAlp().getAddLicenseBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               String txt_user_id = view.getMlf().getLicense_ip().getAlp().getTxt_user_id().getText();
               String txt_app_id = view.getMlf().getLicense_ip().getAlp().getTxt_app_id().getText();
               String txt_license_key = view.getMlf().getLicense_ip().getAlp().getTxt_license_key().getText();
               String txt_license_cost = view.getMlf().getLicense_ip().getAlp().getTxt_license_cost().getText();
               try {
                   model.getMl().addNewLicense(Integer.valueOf(txt_user_id),Integer.valueOf(txt_app_id),txt_license_key,Integer.valueOf(txt_license_cost));
               } catch (IOException ex){
                   throw new RuntimeException(ex);
               }
            }
        });

        view.getMlf().getLicense_ip().getElp().getGetLicenseBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Get License Details Clicked");
                String txt_license_idx = view.getMlf().getLicense_ip().getElp().getTxt_get_license_idx().getText();
                model.getMl().readLicensesJsonFile("src/Model/Licenses/Licenses.json");
                int u_id = model.getMl().getTable().get(Integer.valueOf(txt_license_idx)).getU_temp().getUser_id();
                int a_id = model.getMl().getTable().get(Integer.valueOf(txt_license_idx)).getA_temp().getApp_id();
                String license_key = model.getMl().getTable().get(Integer.valueOf(txt_license_idx)).getLicense_key();
                int license_cost = model.getMl().getTable().get(Integer.valueOf(txt_license_idx)).getLicense_cost();
                view.getMlf().getLicense_ip().getElp().getTxt_app_id().setText(String.valueOf(a_id));
                view.getMlf().getLicense_ip().getElp().getTxt_user_id().setText(String.valueOf(u_id));
                view.getMlf().getLicense_ip().getElp().getTxt_license_key().setText(license_key);
                view.getMlf().getLicense_ip().getElp().getTxt_license_cost().setText(String.valueOf(license_cost));
            }
        });

        view.getMlf().getLicense_ip().getElp().getEditLicenseBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Edit License Button Clicked");
                String txt_license_idx = view.getMlf().getLicense_ip().getElp().getTxt_get_license_idx().getText();
                String txt_user_idx = view.getMlf().getLicense_ip().getElp().getTxt_user_id().getText();
                String txt_app_idx = view.getMlf().getLicense_ip().getElp().getTxt_app_id().getText();
                String txt_license_key = view.getMlf().getLicense_ip().getElp().getTxt_license_key().getText();
                String txt_license_cost = view.getMlf().getLicense_ip().getElp().getTxt_license_cost().getText();
                try {
                    model.getMl().editLicense(Integer.valueOf(txt_license_idx),Integer.valueOf(txt_user_idx),Integer.valueOf(txt_app_idx),txt_license_key,Integer.valueOf(txt_license_cost));
                } catch (IOException ex){
                    throw new RuntimeException(ex);
                }
            }
        });

        view.getMlf().getLicense_ip().getDlp().getDeleteLicenseBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Delete License Button Clicked");
                String txt_license_idx = view.getMlf().getLicense_ip().getDlp().getTxt_del_license_idx().getText();
                try {
                    model.getMl().deleteLicense(Integer.valueOf(txt_license_idx));
                } catch (IOException ex){
                    throw new RuntimeException(ex);
                }
            }
        });
    }
}
