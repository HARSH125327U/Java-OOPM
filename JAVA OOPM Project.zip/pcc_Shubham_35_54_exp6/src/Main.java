import Controller.Controller;
import Model.Licenses.License;
import Model.Licenses.manageLicense;
import Model.Model;
import Model.Softwares.Applications;
import Model.Softwares.appversionException;
//import Model.Users.Users;
import Model.Softwares.manageApplication;
import Model.Users.Users;
import Model.Users.manageUsers;
import Model.Users.mobileNumberException;
import View.View;
import com.fasterxml.jackson.databind.deser.std.CollectionDeserializer;

import javax.swing.text.html.CSS;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;


/**
 * Identification comments:
 * Name: Harsh Tanwani
 * Experiment No: 05
 * Experiment Title:Interactive Object Creation: Empowering Users to Generate Objects
 through Java Input
 * Experiment Date:23/01/2024
 * @version 1.0
 *
 *
 * Beginning comments:
 * Filename: Main.java
 * @author: Harsh Tanwani
 * Overview: This is the main class used to create objects for Airports Class and Softwares
Class. In this file we have achieved the following
 * - Menu Driven Program to create Airports and Softwares
 *
 */
public class Main {
    private static CollectionDeserializer.CollectionReferringAccumulator users;

    public static void main(String[] args) throws IOException {


        View view = new View();
        Model model = new Model();
        Controller controller = new Controller(model,view);

//Creating a Scanner Object to take input
        Scanner sc = new Scanner(System.in);
        ArrayList<Users> users =new ArrayList<>();
        manageUsers mu1=new manageUsers();
        manageApplication ma1=new manageApplication();
        users=mu1.readUserJsonFile("src/Model/Users/User_Data.json");
        users = mu1.getTable();

        ArrayList<Applications> application =new ArrayList<>();
        application=ma1.readAppJsonFile("src/Model/Softwares/Application_Data.json");
        application = ma1.getTable();

        ArrayList<License> licenses = new ArrayList<License>();
        manageLicense ml1 = new manageLicense();
        licenses = ml1.getTable();
        int choice;
// display menu and get user's choice
        do {
            System.out.println("Menu");
            System.out.println("1.Add a User");
            System.out.println("2.Update a User");
            System.out.println("3.Display a User");
            System.out.println("4.Display all Users");
            System.out.println("5.Delete a User");
            System.out.println("6.Add a Software");
            System.out.println("7.Update a Software");
            System.out.println("8.Display a Software");
            System.out.println("9.Display all Software");
            System.out.println("10.Delete a Software");
            System.out.println("11.Add a License");
            System.out.println("12.Delete a License");
            System.out.println("13.Display all License");
            System.out.println("14.Exit");
//Taking input from user
            System.out.println("Enter a Choice");
            choice = sc.nextInt();
            sc.nextLine();
//Execute the selected operation
            switch (choice) {
//Taking user input for each Airports object in the array
                case 1:
                    System.out.println("How do you wish to create User Id");
                    System.out.println("1. Auto Generate Id and Add no other Details");
                    System.out.println("2. Auto Generate Id and Add other Details");
                    System.out.println("3. Provide User Id and Add other Details");
                    System.out.print("Enter your choice: ");
                    int pass_id_choice = sc.nextInt();
                    sc.nextLine();

                    if (pass_id_choice == 1) {
//                      System.out.println("Hello");
                        users.add(new Users());
                        mu1.writeUserJsonFile("src/Model/Users/User_Data.json", users);
                    } else if (pass_id_choice == 2) {
//                        Auto generating id of Users
                        System.out.println("Enter First Name and Last Name");
                        String name = sc.nextLine();
                        String[] name_split = name.split(" ");

                        System.out.println("Enter Address:");
                        String add = sc.nextLine();

                        System.out.println("Enter Id");
                        int id = sc.nextInt();
                        //Displaying Input in uppercase letters
                        String s1 = name.toUpperCase();
                        //Removing the spaces before and after the string using trim function

                        System.out.println("Enter User rating:");
                        int rating = sc.nextInt();

                        System.out.println("Enter Mobile No. :");
                        String mobile = sc.nextLine();
                        try {
                            if (mobile.length() == 10) {
                                users.add(new Users(name_split[0],name_split[1], add, id, rating));
                                mu1.writeUserJsonFile("src/Model/Users/User_Data.json", users);
                            } else {
                                throw new mobileNumberException("Phone number should be of 10 numbers");
                            }
                        } catch (mobileNumberException e) {
                            System.out.println("Custom Exception: " + e.getMessage());
                        }
                    } else if (pass_id_choice == 3) {
                        System.out.println("Enter First Name and Last Name");
                        String name = sc.nextLine();
                        String[] name_split = name.split(" ");

                        System.out.println("Enter Address:");
                        String add = sc.nextLine();


                        System.out.println("Enter Id:");
                        int id = sc.nextInt();

                        System.out.println("Enter User rating:");
                        int rating = sc.nextInt();

                        System.out.println("Enter Mobile No. :");
                        String mobile = sc.nextLine();
                        try {
                            if (mobile.length() == 10) {
                                users.add(new Users(name_split[0],name_split[1], add, id, rating));
                                mu1.writeUserJsonFile("src/Model/Users/User_Data.json", users);
                            } else {
                                throw new mobileNumberException("Phone number should be of 10 numbers");
                            }
                        } catch (mobileNumberException e) {
                            System.out.println("Custom Exception: " + e.getMessage());
                        }
                    }


                case 2:
                    //Taking user input to display specific Airport data
                    System.out.print("Enter Users Index to Update: ");
                    int user_idx = sc.nextInt();
                    sc.nextLine();
                    int choice_to_change;
                    do {
                        System.out.println("1. Change Name: ");
                        System.out.println("2. Change Address: ");
                        System.out.println("3. Change Mobile No. : ");
                        System.out.println("4. Change Id: ");
                        System.out.println("5. Change User Id: ");
                        System.out.println("6. Change User rating: ");
                        System.out.println("7. Exit Update");

                        System.out.print("Enter your choice: ");
                        choice_to_change = sc.nextInt();
                        sc.nextLine();
                        switch (choice_to_change){
                            case 1:
                                System.out.print("Enter Name: ");
                                String name = sc.nextLine();
                                users.get(user_idx).setName(name);
                                mu1.writeUserJsonFile("src/Model/Users/User_Data.json",users);
                                break;
                            case 2:
                                System.out.print("Enter Address: ");
                                String add= sc.nextLine();
                                users.get(user_idx).setAddress(add);
                                mu1.writeUserJsonFile("src/Model/Users/User_Data.json",users);
                                break;
                            case 3:
                                System.out.print("Enter Mobile No. : ");
                                String mobile= sc.nextLine();

                                users.get(user_idx).setMobile(mobile);
                                mu1.writeUserJsonFile("src/Model/Users/User_Data.json",users);

                                break;
                            case 4:
                                System.out.print("Enter Id: ");
                                int id= sc.nextInt();
                                users.get(user_idx).setId(id);
                                mu1.writeUserJsonFile("src/Model/Users/User_Data.json",users);
                                break;
                            case 5:
                                System.out.print("Enter new User Id: ");
                                int user_id= sc.nextInt();
                                users.get(user_idx).setUser_id(user_id);
                                mu1.writeUserJsonFile("src/Model/Users/User_Data.json",users);
                                break;
                            case 6:
                                System.out.print("Enter new User rating: ");
                                int user_rating= sc.nextInt();
                                users.get(user_idx).setUser_rating(user_rating);
                                mu1.writeUserJsonFile("src/Model/Users/User_Data.json",users);
                                break;
                            case 7:
                                System.out.println("Thank You!");
                            default:
                                System.out.println("Invalid choice. Try again.");
                                break;
                        }
                    } while (choice_to_change != 7);
                    break;
                case 3:
                    users=mu1.readUserJsonFile("src/Model/Users/User_Data.json");
                    System.out.println("Enter the index no. of Users");
                    int ind=sc.nextInt();
                    users.get(ind).display();
                    break;
                case 4:
                    users=mu1.readUserJsonFile("src/Model/Users/User_Data.json");
                    for(int i=0;i<users.size();i++){
                        users.get(i).display();
                    }
                    break;


                case 5:
                    users=mu1.readUserJsonFile("src/Model/Users/User_Data.json");
                    System.out.println("Enter the index no. of Users");
                    int indp=sc.nextInt();
                    users.remove(indp);
                    mu1.writeUserJsonFile("src/Model/Users/User_Data.json",users);
                    break;
//Taking user input for each Software object in the array
                case 6:
                    System.out.println("How do you wish to create Software  Id: ");
                    System.out.println("1. Auto Generate Id and Add no other Details");
                    System.out.println("2. Auto Generate Id and Add other Details");
                    System.out.println("3. Provide Software Id");
                    System.out.print("Enter your choice: ");
                    int al_id_choice = sc.nextInt();
                    sc.nextLine();
                    if (al_id_choice == 1) {
                        System.out.println("Auto Generating Software...");
                        application.add(new Applications());
                        ma1.writeAppJsonFile("src/Model/Softwares/Application_Data.json",application);

                    } else if (al_id_choice==2) {
                        System.out.println("Enter the Application name: ");
                        String app_name = sc.nextLine();
                        String[] app_name_split = app_name.split(" ");

                        System.out.println("Enter the Application Release Date: ");
                        String app_date = sc.nextLine();

                        System.out.println("Enter the Software name: ");
                        String soft_name = sc.nextLine();

                        System.out.println("Enter the Software Id: ");
                        int soft_Id = sc.nextInt();

                        System.out.println("Enter the Software Size: ");
                        int soft_size = sc.nextInt();

                        System.out.println("Enter the Application Version: ");
                        String app_ver = sc.nextLine();
                        try {
                            if (app_ver.length() == 2.6) {
                                application.add(new Applications(app_name_split[0], app_ver, app_date, soft_Id, soft_name, soft_size));
                                ma1.writeAppJsonFile("src/Model/Softwares/Application_Data.json", application);
                            } else {
                                throw new appversionException("Version should be 2.6");
                            }
                        } catch (appversionException e) {
                            System.out.println("Custom Exception: " + e.getMessage());
                        }


                        //application.add(new Applications(app_name,app_ver,app_date,soft_Id,soft_name,soft_size));
                       // ma1.writeAppJsonFile("src/Model/Softwares/Application_Data.json", application);
                    } else if (al_id_choice==3) {
                        System.out.println("Enter Application Id: ");
                        int app_ID= sc.nextInt();
                        // To avoid unnecessary skip of input
                        sc.nextLine();

                        System.out.println("Enter the Application name: ");
                        String app_name = sc.nextLine();
                        String[] app_name_split = app_name.split(" ");

                        System.out.println("Enter the Application Release Date: ");
                        String app_date = sc.nextLine();

                        System.out.println("Enter the Software name: ");
                        String soft_name = sc.nextLine();

                        System.out.println("Enter Software Id: ");
                        int soft_Id= sc.nextInt();
                        // To avoid unnecessary skip of input
                        sc.nextLine();

                        System.out.println("Enter the Software Size: ");
                        int soft_size = sc.nextInt();

                        System.out.println("Enter the Application Version: ");
                        String app_ver = sc.nextLine();
                        try {
                            if (app_ver.length() == 2.6) {
                                application.add(new Applications(app_ID,app_name_split[0], app_ver, app_date, soft_Id, soft_name, soft_size));
                                ma1.writeAppJsonFile("src/Model/Teachers/teachers.json", application);
                            } else {
                                throw new appversionException("Version should be 2.6");
                            }
                        } catch (appversionException e) {
                            System.out.println("Custom Exception: " + e.getMessage());
                        }

                        //System.out.println(Applications.getApp_count() + " ");
                        //application.add(new Applications(app_ID,app_name,app_ver,app_date,soft_Id,soft_name,soft_size));

                        //ma1.writeAppJsonFile("src/Model/Softwares/Application_Data.json",application);
                    }
                    break;
                case 7:
                    //Taking user input to display specific Airport data
                    System.out.print("Enter Software Index to Update: ");
                    int app_idx = sc.nextInt();
                    sc.nextLine();
                    int choice_to_change_app;
                    do {
                        System.out.println("1. Change Software Id");
                        System.out.println("2. Change Software Name");
                        System.out.println("3. Change Software Size");
                        System.out.println("4.Exit");

                        System.out.print("Enter your choice: ");
                        choice_to_change_app = sc.nextInt();
                        sc.nextLine();
                        switch (choice_to_change_app){
                            case 1:
                                System.out.print("Enter Software Id: ");
                                int soft_id = sc.nextInt();
                                application.get(app_idx).setSoftware_id(soft_id);
                                ma1.writeAppJsonFile("src/Model/Softwares/Application_Data.json",application);
                                break;
                            case 2:
                                System.out.print("Enter Software Name: ");
                                String soft_name = sc.nextLine();
                                application.get(app_idx).setSoftware_name(soft_name);
                                ma1.writeAppJsonFile("src/Model/Softwares/Application_Data.json",application);
                                break;
                            case 3:
                                System.out.print("Enter Software Size: ");
                                int soft_size= sc.nextInt();
                                application.get(app_idx).setSoftware_size(soft_size);
                                ma1.writeAppJsonFile("src/Model/Softwares/Application_Data.json",application);
                                break;

                            case 4:
                                System.out.println("Thank You!");
                            default:
                                System.out.println("Invalid choice. Try again.");
                                break;
                        }
                    } while (choice_to_change_app != 4);
                    break;
                case 8:
                    application=ma1.readAppJsonFile("src/Model/Softwares/Application_Data.json");
                    System.out.println("Enter the index no. of Users");
                    int inda=sc.nextInt();
                    application.get(inda).display();
                    break;
                case 9:
                    application=ma1.readAppJsonFile("src/Model/Softwares/Application_Data.json");
                    for (Applications applications : application) {
                        applications.display();
                    }
                    break;


                case 10:
                    application=ma1.readAppJsonFile("src/Model/Softwares/Application_Data.json");
                    System.out.println("Enter the index no. of Users");
                    int indai=sc.nextInt();
                    application.remove(indai);
                    ma1.writeAppJsonFile("src/Model/Softwares/Application_Data.json",application);
                    break;

                case 11:
                    application = ma1.readAppJsonFile("src/Model/Softwares/Application_Data.json");
                    users = mu1.readUserJsonFile("src/Model/Users/User_Data.json");

                    System.out.println("Enter Application Index to be Licensed: ");
                    int app_idx_lic = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter User Index to be Licensed: ");
                    int user_idx_lic = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter the License Key: ");
                    String lic_key = sc.nextLine();
                    System.out.println("Enter the License cost: ");
                    int lic_cost = sc.nextInt();
                    sc.nextLine();
                    License li = new License(application.get(app_idx_lic),users.get(user_idx_lic),lic_key,lic_cost);
                    licenses.add(li);
                    ml1.writeLicensesJsonFile("src/Model/Licenses/Licenses.json",licenses);
                case 12:
                    application = ma1.readAppJsonFile("Model/Licenses/Licenses.json");
                    users = mu1.readUserJsonFile("src/Model/Users/User_Data.json");

                    System.out.println("Enter Application Index to Delete License: ");
                    int app_idx_lic_del = sc.nextInt();
                    sc.nextLine();
                    System.out.println("Enter User Index to Delete License: ");
                    int user_idx_lic_del = sc.nextInt();
                    sc.nextLine();

                    for(int i =0;i<licenses.size();i++){
                        if(app_idx_lic_del == licenses.get(i).getA_temp().getApp_id() && user_idx_lic_del == licenses.get(i).getU_temp().getUser_id()){
                            licenses.remove(i);
                        }
                    }
                    break;

                case 13:
                    licenses = ml1.readLicensesJsonFile("Model/Licenses/Licenses.json");

                    for (int i=0; i<licenses.size();i++)
                    {
                        System.out.println("Application Name : "+licenses.get(i).getA_temp().getApp_name()+" "+licenses.get(i).getA_temp().getSoftware_name());
                        System.out.println("User Name : "+licenses.get(i).getU_temp().getName());
                        System.out.println("License Key : "+licenses.get(i).getLicense_key());
                        System.out.println("License Cost : "+licenses.get(i).getLicense_cost());
                    }

                default:
                    // invalid choice
                    System.out.println("Invalid choice, please try again.");
                    break;
            }
        } while (choice !=14);
    }
}