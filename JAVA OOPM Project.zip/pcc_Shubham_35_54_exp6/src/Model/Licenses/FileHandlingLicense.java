package Model.Licenses;


import java.io.IOException;
import java.util.ArrayList;
public abstract class FileHandlingLicense{
    protected abstract ArrayList<License> readLicensesJsonFile(String file_path);
    protected abstract void writeLicensesJsonFile(String file_path, ArrayList<License> enrolls) throws IOException;
}
