package Model.Licenses;
import Model.Softwares.*;
import Model.Users.*;

public class License {
    Applications a_temp;
    Users u_temp;
    String license_key;
    int license_cost;
    public License(Applications a,Users u,String l_key,int l_cost){
        setA_temp(a);
        setU_temp(u);
        setLicense_cost(l_cost);
        setLicense_key(l_key);
    }

    public void setA_temp(Applications a_temp) {
        this.a_temp = a_temp;
    }

    public void setLicense_cost(int license_cost) {
        this.license_cost = license_cost;
    }

    public void setLicense_key(String license_key) {
        this.license_key = license_key;
    }

    public void setU_temp(Users u_temp) {
        this.u_temp = u_temp;
    }

    public Applications getA_temp() {
        return a_temp;
    }

    public Users getU_temp() {
        return u_temp;
    }

    public int getLicense_cost() {
        return license_cost;
    }

    public String getLicense_key() {return license_key;}
}
