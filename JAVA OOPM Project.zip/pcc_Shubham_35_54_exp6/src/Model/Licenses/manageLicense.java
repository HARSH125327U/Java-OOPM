package Model.Licenses;

import Model.Softwares.*;
import Model.Users.*;
import Model.Displayable;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class manageLicense extends FileHandlingLicense implements Displayable {

    ArrayList<Applications> apps = new ArrayList<>();
    ArrayList<Users> users = new ArrayList<>();
    ArrayList<License> license_data = new ArrayList<>();

    ObjectMapper objectMapper = new ObjectMapper();

    private int linesBeingDisplayed;
    private int firstLineIndex;
    private int lastLineIndex;
    private int highlightedLine;

    public manageLicense() {
        manageApplication ma1=new manageApplication();
        apps=ma1.getTable();
        manageUsers mu1=new manageUsers();
        users=mu1.getTable();
        readLicensesJsonFile("src/Model/Licenses/Licenses.json");
    }

    public ArrayList<License> readLicensesJsonFile(String file_path) {
        try {
            JsonNode rootNode = objectMapper.readTree(new File(file_path));

            if (rootNode.isArray()) {
                for (JsonNode node : rootNode) {
                    int a_temp = node.has("a_temp")?node.get("a_temp").asInt():0;
                    int u_temp = node.has("u_temp")?node.get("u_temp").asInt():0;
                    String license_key = node.has("license_key")?node.get("license_key").asText():null;
                    int license_cost=node.has("license_cost")?node.get("license_cost").asInt():0;

                    Applications a_temp_obj=null;
                    Users u_temp_obj=null;

                    for(int i = 0; i < apps.size(); i++)
                    {
                        if(a_temp == apps.get(i).getApp_id())
                        {
                            a_temp_obj = apps.get(i);
                        }
                    }
                    for(int i = 0; i < users.size(); i++)
                    {
                        if(u_temp == users.get(i).getUser_id())
                        {
                            u_temp_obj = users.get(i);
                        }
                    }

                    License l_temp=new License(a_temp_obj,u_temp_obj,license_key,license_cost);
                    license_data.add(l_temp);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return license_data;
    }

    public void writeLicensesJsonFile(String file_path, ArrayList<License> license_al) throws IOException {
        ArrayList<Map<String, Object>> license_to_be_written = new ArrayList<>();

        for (int i = 0; i < license_al.size(); i++) {
            HashMap<String, Object> data = new HashMap<>();
            data.put("a_temp", license_al.get(i).getA_temp().getApp_id());
            data.put("u_temp", license_al.get(i).getU_temp().getUser_id());
            data.put("enroll_date", license_al.get(i).getLicense_key());
            data.put("course_fees", license_al.get(i).getLicense_cost());

            license_to_be_written.add(data);
        }

        objectMapper.writeValue(Paths.get(file_path).toFile(), license_to_be_written);
    }

    public ArrayList<String> getHeaders() {
        ArrayList<String> headers = new ArrayList<String>();
        headers.add("Application Name");
        headers.add("User Name");
        headers.add("License Key");
        headers.add("License Cost");

        return headers;
    }

    public void setAppsTable(ArrayList<Applications> apps) {
        this.apps = apps;
    }

    @Override
    public ArrayList<String> getLine(int line) {
        ArrayList<String> license_datails = new ArrayList<String>();
        license_datails.add(license_data.get(line).getA_temp().getApp_name());
        license_datails.add(license_data.get(line).getU_temp().getName());
        license_datails.add(license_data.get(line).getLicense_key());
        license_datails.add(String.valueOf(license_data.get(line).getLicense_cost()));
        return license_datails;
    }

    @Override
    public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine) {
        ArrayList<ArrayList<String>> license_subset = new ArrayList<>();

        for (int i = firstLine; i <= lastLine; i++) {
            license_subset.add(getLine(i));
        }
        return license_subset;
    }

    @Override
    public int getFirstLineToDisplay() {
        return firstLineIndex;
    }

    @Override
    public int getLineToHighlight() {
        return highlightedLine;
    }

    @Override
    public int getLastLineToDisplay() {
        setLastLineToDisplay(getFirstLineToDisplay() + getLinesBeingDisplayed() - 1);
        return lastLineIndex;
    }

    @Override
    public int getLinesBeingDisplayed() {
        return linesBeingDisplayed;
    }

    @Override
    public void setFirstLineToDisplay(int firstLine) {
        this.firstLineIndex = firstLine;
    }

    @Override
    public void setLineToHighlight(int highlightedLine) {
        this.highlightedLine = highlightedLine;
    }

    @Override
    public void setLastLineToDisplay(int lastLine) {
        this.lastLineIndex = lastLine;
    }

    @Override
    public void setLinesBeingDisplayed(int numberOfLines) {
        this.linesBeingDisplayed = numberOfLines;
    }

    public ArrayList<License> getTable() {
        return license_data;
    }

    public void addNewLicense(int user_id,int Software_id,String license_key,int license_cost)throws IOException{
        readLicensesJsonFile("src/Model/Licenses/Licenses.json");
        License temp_license = new License(apps.get(Software_id), users.get(user_id),license_key,license_cost);
        license_data.add(temp_license);
        writeLicensesJsonFile("src/Model/Licenses/Licenses.json",license_data);
    }

    public void editLicense(int edit_license_idx,int user_id,int Software_id,String license_key,int license_cost) throws IOException{
        readLicensesJsonFile("src/Model/Licenses/Licenses.json");
        license_data.get(edit_license_idx).setLicense_cost(license_cost);
        license_data.get(edit_license_idx).setLicense_key(license_key);
        license_data.get(edit_license_idx).setA_temp(apps.get(Software_id));
        license_data.get(edit_license_idx).setU_temp(users.get(user_id));
        writeLicensesJsonFile("src/Model/Licenses/Licenses.json",license_data);
    }

    public void deleteLicense(int delete_license_idx) throws IOException{
        readLicensesJsonFile("src/Model/Licenses/Licenses.json");
        license_data.remove(delete_license_idx);
        writeLicensesJsonFile("src/Model/Licenses/Licenses.json",license_data);
    }
}
