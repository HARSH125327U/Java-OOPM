package Model;

import Model.Users.manageUsers;
import Model.Softwares.manageApplication;
import Model.Licenses.manageLicense;

public class Model {
    manageUsers mu;
    manageApplication ma;
    manageLicense ml;

    public Model(){
        mu = new manageUsers();
        ma = new manageApplication();
        ml = new manageLicense();

    }

    public manageUsers getMu(){return mu;}

    public manageApplication getMa() {
        return ma;
    }

    public manageLicense getMl() {
        return ml;
    }

    public void setMu(manageUsers mu) {
        this.mu = mu;
    }

    public void setMa(manageApplication ma) {
        this.ma = ma;
    }

    public void setMl(manageLicense ml) {
        this.ml = ml;
    }
}
