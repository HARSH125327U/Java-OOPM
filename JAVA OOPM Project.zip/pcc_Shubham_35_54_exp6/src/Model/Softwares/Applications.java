package Model.Softwares;

public class Applications extends Software{
    private static int app_count=0;
    int app_id;
    String app_name;
    String version;
    String release_date;

    public static int getApp_count(){ return app_count;}
    public static void setApp_count(int app_count){ Applications.app_count=app_count;}

    public Applications(){
        setApp_count(getApp_count()+1);
        this.setApp_id(app_count);
    }
    public  Applications(String app_name,String version,String release_date,int software_id,String Software_name, int Software_size){
        //calling the constructor of superclass(Software)
        super( software_id,Software_name,Software_size);
        //Incrementing Application_cnt and initializing App_id
        setApp_count(getApp_count()+1);
        this.setApp_id(app_count);
        this.setApp_name(app_name);
        this.setVersion(version);
        this.setRelease_date(release_date);
    }
    public  Applications(int app_id,String app_name,String version,String release_date,int software_id,String Software_name, int Software_size){
        //calling the constructor of superclass(Software)
        super( software_id,Software_name,Software_size);
        //Incrementing Application_cnt
        setApp_count(getApp_count()+1);
        this.setApp_id(app_id);
        this.setApp_name(app_name);
        this.setVersion(version);
        this.setRelease_date(release_date);
    }
    public void setApp_id(int app_id) { this.app_id=app_id;}
    public void setApp_name(String app_name){ this.app_name=app_name;}
    public void setVersion(String version){ this.version=version;}
    public void setRelease_date(String release_date){ this.release_date=release_date;}

    public int getApp_id(){ return app_id;}
    public String getApp_name(){ return app_name;}
    public String getVersion(){ return version;}
    public String getRelease_date(){ return release_date;}

    public void display()
    {
        System.out.println("App ID:"+getApp_id());
        System.out.println("App name:"+getApp_name());
        System.out.println("App version:"+getVersion());
        System.out.println("App release data:"+getRelease_date());
        super.display();
    }


}
