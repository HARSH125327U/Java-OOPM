package Model.Softwares;

import java.io.IOException;
import java.util.ArrayList;

public abstract class FileHandlingApplications {
    protected abstract ArrayList<Applications> readAppJsonFile(String file_path);

    protected abstract void writeAppJsonFile(String file_path, ArrayList<Applications> apps) throws IOException;
}
