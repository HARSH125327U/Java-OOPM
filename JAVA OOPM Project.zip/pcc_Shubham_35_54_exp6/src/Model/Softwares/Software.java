package Model.Softwares;

public class Software {
    int Software_id;
    String Software_name;
    int Software_size;
    public Software()
    {
        System.out.println("Creating a Software");
    }
    public Software(int software_id,String Software_name, int Software_size)
    {
        this.setSoftware_id(software_id);
        this.setSoftware_name(Software_name);
        this.setSoftware_size(Software_size);
    }
    public void setSoftware_id(int software_id) {
        this.Software_id = software_id;
    }
    public void setSoftware_name(String software_name) {
        Software_name = software_name;
    }
    public void setSoftware_size(int software_size) {
        Software_size = software_size;
    }

    public int getSoftware_id() {
        return Software_id;
    }
    public int getSoftware_size() {
        return Software_size;
    }
    public String getSoftware_name() {
        return Software_name;
    }
    public void display(){
        System.out.println("Software id: " + getSoftware_id());
        System.out.println("Software Name : " + getSoftware_name());
        System.out.println("Software size:" + getSoftware_size());
    }
}
