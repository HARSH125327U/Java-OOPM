package Model.Softwares;

public class appversionException extends Exception {
    public appversionException(String Message){
        super(Message);
    }
}
