package Model.Softwares;

import Model.Displayable;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;

public class manageApplication extends FileHandlingApplications implements Displayable {

    private ArrayList<Applications> apps = new ArrayList<>();
    private ObjectMapper objectMapper = new ObjectMapper();

    private int linesBeingDisplayed;
    private int firstLineIndex;
    private int lastLineIndex;
    private int highlightedLine;

    public manageApplication() {
        readAppJsonFile("src/Model/Softwares/Application_Data.json");
    }

    public ArrayList<Applications> readAppJsonFile(String file_path) {
        try {
            JsonNode rootNode = objectMapper.readTree(new File(file_path));

            if (rootNode.isArray()) {
                for (JsonNode node : rootNode) {
                    int Software_id = node.has("Software_id")?node.get("Software_id").asInt():0;
                    String Software_name = node.has("Software_name")?node.get("Software_name").asText():null;
                    int Software_size = node.has("Software_size")?node.get("Software_size").asInt():500;
                    int app_id = node.has("app_id")?node.get("app_id").asInt():0;
                    String app_name = node.has("app_name")?node.get("app_name").asText():null;
                    String version = node.has("version")?node.get("version").asText():null;
                    String release_date = node.has("release_date")?node.get("release_date").asText():null;

                    apps.add(new Applications(app_id, app_name, version, release_date, Software_id, Software_name, Software_size));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return apps;
    }

    public void writeAppJsonFile(String file_path, ArrayList<Applications> apps) throws IOException {
        objectMapper.writeValue(Paths.get(file_path).toFile(), apps);
    }

    public void setAppsTable(ArrayList<Applications> apps) {
        this.apps = apps;
    }

    public ArrayList<String> getHeaders() {
        ArrayList<String> headers = new ArrayList<>();
        headers.add("App ID");
        headers.add("App Name");
        headers.add("Version");
        headers.add("Release Date");
        headers.add("Software ID");
        headers.add("Software Name");
        headers.add("Software Size");
        return headers;
    }

    @Override
    public ArrayList<String> getLine(int line) {
        ArrayList<String> appDetails = new ArrayList<>();

        Applications app = apps.get(line);
        appDetails.add(String.valueOf(app.getApp_id()));
        appDetails.add(app.getApp_name());
        appDetails.add(app.getVersion());
        appDetails.add(app.getRelease_date());
        appDetails.add(String.valueOf(app.getSoftware_id()));
        appDetails.add(app.getSoftware_name());
        appDetails.add(String.valueOf(app.getSoftware_size()));

        return appDetails;
    }

    @Override
    public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine) {
        ArrayList<ArrayList<String>> appsSubset = new ArrayList<>();

        for (int i = firstLine; i <= lastLine; i++) {
            appsSubset.add(getLine(i));
        }
        return appsSubset;
    }

    @Override
    public int getFirstLineToDisplay() {
        return firstLineIndex;
    }

    @Override
    public int getLineToHighlight() {
        return highlightedLine;
    }

    @Override
    public int getLastLineToDisplay() {
        setLastLineToDisplay(getFirstLineToDisplay() + getLinesBeingDisplayed() - 1);
        return lastLineIndex;
    }

    @Override
    public int getLinesBeingDisplayed() {
        return linesBeingDisplayed;
    }

    @Override
    public void setFirstLineToDisplay(int firstLine) {
        this.firstLineIndex = firstLine;
    }

    @Override
    public void setLineToHighlight(int highlightedLine) {
        this.highlightedLine = highlightedLine;
    }

    @Override
    public void setLastLineToDisplay(int lastLine) {
        this.lastLineIndex = lastLine;
    }

    @Override
    public void setLinesBeingDisplayed(int numberOfLines) {
        this.linesBeingDisplayed = numberOfLines;
    }

    public ArrayList<Applications> getTable() {
        readAppJsonFile("src/Model/Softwares/Application_Data.json");
        return apps;
    }

    public void addNewApplication(int app_id,String app_name,String app_version,String release_date,int Software_id,String Software_name,int Software_size) throws IOException{
        readAppJsonFile("src/Model/Softwares/Application_Data.json");
        Applications temp_user = new Applications(app_id,app_name,app_version,release_date,Software_id,Software_name,Software_size);
        apps.add(temp_user);
        writeAppJsonFile("src/Model/Softwares/Application_Data.json",apps);
    }

    public void editApplication(int edit_software_idx,int edit_app_idx,int app_id,String app_name,String app_version,String release_date,int Software_id,String Software_name,int Software_size)throws  IOException{
        readAppJsonFile("src/Model/Softwares/Application_Data.json");
        apps.get(edit_app_idx).setApp_id(app_id);
        apps.get(edit_app_idx).setApp_name(app_name);
        apps.get(edit_app_idx).setVersion(app_version);
        apps.get(edit_app_idx).setRelease_date(release_date);
        apps.get(edit_software_idx).setSoftware_id(Software_id);
        apps.get(edit_software_idx).setSoftware_name(Software_name);
        apps.get(edit_software_idx).setSoftware_size(Software_size);
        writeAppJsonFile("src/Model/Softwares/Application_Data.json",apps);
    }

    public int deleteApplication(int del_app_idx) throws IOException{
        readAppJsonFile("src/Model/Softwares/Application_Data.json");
        apps.remove(del_app_idx);
        int a_id = apps.get(del_app_idx).getApp_id();
        writeAppJsonFile("src/Model/Softwares/Application_Data.json",apps);
        return a_id;
    }
}
