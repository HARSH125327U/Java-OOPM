package Model.Users;

import java.io.IOException;
import java.util.ArrayList;
/**
 * Identification comments:
 *   Name: Harsh Tanwani
 *   Experiment No: 06
 *   Experiment Title: Implementation of Abstract Class and Abstract Method for the entities of the relationship
 *   Experiment Date: 13/02/2024
 *   @version 1.0
 *
 *
 * Beginning comments:
 * Filename: FileHandlingPerson.java
 * Overview: This abstract class serves as a blueprint for handling application data through file operations.
 * In this file, we have achieved the following:
 * - Created abstract methods for reading and writing airline information to/from a JSON file
 */

//An abstract class for handling airline data through file operations.
public abstract class FileHandlingPerson {

    //Reads application information from a JSON file.
    protected abstract ArrayList<Users> readUserJsonFile(String file_path);

    //Writes airline information to a JSON file.
    protected abstract void writeUserJsonFile(String file_path, ArrayList<Users> users) throws IOException;
}
