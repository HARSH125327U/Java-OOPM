package Model.Users;

public class Person {
    private int id;
    private String Name;
    private String address;
    private String mobile;
    // Default constructor
    public Person() {
        System.out.println("Creating a Person");
    }
    // Parametrized constructor
    public Person(String Name,String address,String Mobile,int id)
    {
        this.setName(Name);
        this.setAddress(address);
        this.setMobile(Mobile);
        this.setId(id);

    }
    //Getters and Setters
    public void setName(String Name) {this.Name = Name;}
    public void setAddress(String address){this.address=address;}
    public void setMobile(String mobile) {this.mobile = mobile;}
    public void setId(int id){this.id=id;}
    public String getName() {return Name;}
    public String getAddress() {return address;}
    public String getMobile() {return mobile;}
    public int getId(){return id;}
    public void display() {
        System.out.println("Name: " + getName());
        System.out.println("Address: " + getAddress());
        System.out.println("Mobile: " + getMobile());
        System.out.println("Id:" + getId());
    }


}
