package Model.Users;

public class Users extends Person {
    private static int user_count = 0;
    private int user_id;
    private int user_rating;

    public static int getUser_count() {
        return user_count;
    }



    public Users() {
        setUser_count(getUser_count() + 1);
        this.setUser_id(user_count);
    }

    public Users(String name, String address, String mobile, int id, int user_rating) {
        super(name, address, mobile, id);
        setUser_count(getUser_count() + 1);
        this.setUser_id(user_count);
        this.user_rating = user_rating;
    }

    public Users(String name, String address, String mobile, int id, int user_id, int user_rating) {
        super(name, address, mobile, id);
        setUser_count(getUser_count()+1);
        this.setUser_id(user_id);
        this.user_rating = user_rating;
    }

    public static void setUser_count(int user_count) {
        Users.user_count = user_count;
    }
    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public int getUser_rating() {
        return user_rating;
    }

    public void setUser_rating(int user_rating) {
        this.user_rating = user_rating;
    }

    @Override
    public void display() {
        System.out.println("User Id: " + getUser_id());
        super.display();
        System.out.println("User Rating: " + getUser_rating());
    }
}
