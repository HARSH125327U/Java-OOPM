package Model.Users;

import Model.Displayable;
import Model.Softwares.Applications;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;

public class manageUsers extends FileHandlingPerson implements Displayable {

    ArrayList<Users> users = new ArrayList<>();
    ObjectMapper objectMapper = new ObjectMapper();

    private int linesBeingDisplayed;
    private int firstLineIndex;
    private int lastLineIndex;
    private int highlightedLine;

    public manageUsers() {
        readUserJsonFile("src/Model/Users/User_Data.json");
    }

    public ArrayList<Users> readUserJsonFile(String file_path) {
        try {
            JsonNode rootNode = objectMapper.readTree(new File(file_path));

            if (rootNode.isArray()) {
                for (JsonNode node : rootNode) {
                    String name = node.has("Name") ? node.get("Name").asText() : null;
                    String address = node.has("address") ? node.get("address").asText() : null;
                    String mobile = node.has("mobile") ? node.get("mobile").asText() : null;
                    int id = node.has("id") ? node.get("id").asInt() : 0; // Or any default value
                    int user_id = node.has("user_id") ? node.get("user_id").asInt() : 0;
                    int rating = node.has("user_rating") ? node.get("user_rating").asInt() : 0; // Or any default value

                    users.add(new Users(name, address, mobile,id,user_id,rating));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return users;
    }

    public void writeUserJsonFile(String file_path, ArrayList<Users> users) throws IOException {
        objectMapper.writeValue(Paths.get(file_path).toFile(), users);
    }

    @Override
    public ArrayList<String> getLine(int line) {
        ArrayList<String> user_details = new ArrayList<>();

        Users user = users.get(line);
        user_details.add(String.valueOf(user.getUser_id()));
        user_details.add(user.getName());
        user_details.add(user.getAddress());
        user_details.add(user.getMobile());
        user_details.add(String.valueOf(user.getId()));
        user_details.add(String.valueOf(user.getUser_rating()));

        return user_details;
    }

    @Override
    public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine) {
        ArrayList<ArrayList<String>> users_subset = new ArrayList<ArrayList<String>>();

        for (int i = firstLine; i <= lastLine; i++) {
            users_subset.add(getLine(i));
        }
        return users_subset;
    }

    @Override
    public int getFirstLineToDisplay() {
        return firstLineIndex;
    }

    @Override
    public int getLineToHighlight() {
        return highlightedLine;
    }

    @Override
    public int getLastLineToDisplay() {
        setLastLineToDisplay(getFirstLineToDisplay() + getLinesBeingDisplayed() - 1);
        return lastLineIndex;
    }

    @Override
    public int getLinesBeingDisplayed() {
        return linesBeingDisplayed;
    }

    @Override
    public void setFirstLineToDisplay(int firstLine) {
        this.firstLineIndex = firstLine;
    }

    @Override
    public void setLineToHighlight(int highlightedLine) {
        this.highlightedLine = highlightedLine;
    }

    @Override
    public void setLastLineToDisplay(int lastLine) {
        this.lastLineIndex = lastLine;
    }

    @Override
    public void setLinesBeingDisplayed(int numberOfLines) {
        this.linesBeingDisplayed = numberOfLines;
    }

    public void setUsersTable(ArrayList<Users> users) {
        this.users = users;
    }

    public ArrayList<Users> getTable() {
        return users;
    }

    public ArrayList<String> getHeaders() {
        ArrayList<String> headers = new ArrayList<>();
        headers.add("Id");
        headers.add("Name");
        headers.add("Address");
        headers.add("Mobile");
        headers.add("User Id");
        headers.add("Rating");
        return headers;
    }
    public void addNewUser(String Name,String Address,String mobile,int id,int user_id,int user_rating) throws IOException{
        readUserJsonFile("src/Model/Users/User_Data.json");
        Users temp_user = new Users(Name,Address,mobile,id,user_id,user_rating);
        users.add(temp_user);
        writeUserJsonFile("src/Model/Users/User_Data.json",users);
    }

    public void editUser(int edit_person_idx,int edit_user_idx,String Name,String Address,String mobile,int id,int user_id,int user_rating)throws  IOException{
        readUserJsonFile("src/Model/Users/User_Data.json");
        users.get(edit_person_idx).setId(id);
        users.get(edit_person_idx).setName(Name);
        users.get(edit_person_idx).setAddress(Address);
        users.get(edit_person_idx).setMobile(mobile);
        users.get(edit_user_idx).setUser_id(user_id);
        users.get(edit_user_idx).setUser_rating(user_rating);
        writeUserJsonFile("src/Model/Users/User_Data.json",users);
    }

    public int deleteUser(int del_user_idx) throws IOException{
        readUserJsonFile("src/Model/Users/User_Data.json");
        users.remove(del_user_idx);
        int u_id = users.get(del_user_idx).getUser_id();
        writeUserJsonFile("src/Model/Users/User_Data.json",users);
        return u_id;
    }
}
