package Model.Users;
import java.io.IOException;
public class mobileNumberException extends Exception {
    public mobileNumberException(String message){
        super(message);
    }
}
