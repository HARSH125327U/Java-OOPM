package View;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
public class AddPanelUser extends JPanel {
    JTextField txt_Name;
    JTextField txt_address;
    JTextField txt_mobile;
    JTextField txt_id;
    JTextField txt_user_id;
    JTextField txt_user_rating;
    JButton addUserBtn;
    public AddPanelUser() {
        txt_Name = new JTextField();
        txt_address = new JTextField();
        txt_mobile = new JTextField();
        txt_id = new JTextField();
        txt_user_id = new JTextField();
        txt_user_rating = new JTextField();
        addUserBtn = new JButton("Add a User");

        txt_Name.setText("Name: ");
        txt_address.setText("Address: ");
        txt_mobile.setText("Mobile: ");
        txt_id.setText("Id: ");
        txt_user_id.setText("User Id: ");
        txt_user_rating.setText("User Rating: ");

        add(txt_Name);
        add(txt_address);
        add(txt_mobile);
        add(txt_id);
        add(txt_user_id);
        add(txt_user_rating);
        add(addUserBtn);
    }

    public void setTxt_Name(JTextField txt_Name) {
        this.txt_Name = txt_Name;
    }

    public void setTxt_address(JTextField txt_address) {
        this.txt_address = txt_address;
    }

    public void setTxt_mobile(JTextField txt_mobile) {
        this.txt_mobile = txt_mobile;
    }

    public void setTxt_id(JTextField txt_id) {
        this.txt_id = txt_id;
    }

    public void setTxt_user_id(JTextField txt_user_id) {
        this.txt_user_id = txt_user_id;
    }

    public void setTxt_user_rating(JTextField txt_user_rating) {
        this.txt_user_rating = txt_user_rating;
    }

    public void setAddUserBtn(JButton addUserBtn) {
        this.addUserBtn = addUserBtn;
    }

    public JTextField getTxt_Name() {
        return txt_Name;
    }

    public JTextField getTxt_address() {
        return txt_address;
    }

    public JTextField getTxt_mobile() {
        return txt_mobile;
    }

    public JTextField getTxt_id() {
        return txt_id;
    }

    public JTextField getTxt_user_id() {
        return txt_user_id;
    }

    public JTextField getTxt_user_rating() {
        return txt_user_rating;
    }

    public JButton getAddUserBtn() {
        return addUserBtn;
    }
}
