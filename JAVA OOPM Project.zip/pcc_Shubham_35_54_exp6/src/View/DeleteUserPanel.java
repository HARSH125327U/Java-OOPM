package View;

import javax.swing.*;

public class DeleteUserPanel extends JPanel{
    JTextField txt_del_user_id;
    JTextField txt_del_person_id;
    JButton deleteUserBtn;

    public DeleteUserPanel(){
        txt_del_user_id = new JTextField();
        txt_del_person_id = new JTextField();
        deleteUserBtn = new JButton("Delete User");

        txt_del_user_id.setText("txt_del_user_id");
        txt_del_person_id.setText("txt_del_person_id");
        add(txt_del_person_id);
        add(txt_del_user_id);
        add(deleteUserBtn);
    }

    public void setTxt_del_person_id(JTextField txt_del_person_id) {
        this.txt_del_person_id = txt_del_person_id;
    }

    public void setTxt_del_user_id(JTextField txt_del_user_id) {
        this.txt_del_user_id = txt_del_user_id;
    }

    public void setDeleteUserBtn(JButton deleteUserBtn) {
        this.deleteUserBtn = deleteUserBtn;
    }

    public JTextField getTxt_del_person_id() {
        return txt_del_person_id;
    }

    public JTextField getTxt_del_user_id() {
        return txt_del_user_id;
    }

    public JButton getDeleteUserBtn() {
        return deleteUserBtn;
    }
}
