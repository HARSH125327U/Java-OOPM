package View;

import javax.swing.*;

public class EditUserPanel extends JPanel {
    JTextField txt_get_user_idx;
    JButton getUserBtn;
    JTextField txt_user_id;
    JTextField txt_user_rating;
    JTextField txt_person_idx;
    JTextField txt_id;
    JTextField txt_Name;
    JTextField txt_address;
    JTextField txt_mobile;
    JButton editUserBtn;

    public EditUserPanel(){
        txt_user_id = new JTextField();
        txt_user_rating = new JTextField();
        txt_get_user_idx = new JTextField();
        txt_id = new JTextField();
        txt_Name = new JTextField();
        txt_address = new JTextField();
        txt_mobile = new JTextField();
        txt_person_idx = new JTextField();
        getUserBtn = new JButton("Get User to Edit");
        editUserBtn = new JButton("Edit User");

        txt_user_id.setText("txt_user_id");
        txt_user_rating.setText("txt_user_rating");
        txt_get_user_idx.setText("Get User id");
        txt_id.setText("txt_id");
        txt_Name.setText("txt_Name");
        txt_address.setText("txt_address");
        txt_mobile.setText("txt_mobile");
        txt_person_idx.setText("Get Person id");

        add(txt_get_user_idx);
        add(txt_person_idx);
        add(txt_user_id);
        add(txt_user_rating);
        add(txt_id);
        add(txt_Name);
        add(txt_address);
        add(txt_mobile);
        add(editUserBtn);
        add(getUserBtn);
    }

    public void setTxt_user_id(JTextField txt_user_id) {
        this.txt_user_id = txt_user_id;
    }

    public void setTxt_user_rating(JTextField txt_user_rating) {
        this.txt_user_rating = txt_user_rating;
    }

    public void setTxt_get_user_idx(JTextField txt_get_user_idx) {
        this.txt_get_user_idx = txt_get_user_idx;
    }

    public void setTxt_id(JTextField txt_id) {
        this.txt_id = txt_id;
    }

    public void setTxt_Name(JTextField txt_Name) {
        this.txt_Name = txt_Name;
    }

    public void setTxt_person_idx(JTextField txt_person_idx) {
        this.txt_person_idx = txt_person_idx;
    }

    public void setTxt_mobile(JTextField txt_mobile) {
        this.txt_mobile = txt_mobile;
    }

    public void setTxt_address(JTextField txt_address) {
        this.txt_address = txt_address;
    }

    public void setEditUserBtn(JButton editUserBtn) {
        this.editUserBtn = editUserBtn;
    }

    public void setGetUserBtn(JButton getUserBtn) {
        this.getUserBtn = getUserBtn;
    }

    public JTextField getTxt_user_id() {
        return txt_user_id;
    }

    public JTextField getTxt_user_rating() {
        return txt_user_rating;
    }

    public JTextField getTxt_get_user_idx() {
        return txt_get_user_idx;
    }

    public JTextField getTxt_person_idx() {
        return txt_person_idx;
    }

    public JTextField getTxt_id() {
        return txt_id;
    }

    public JTextField getTxt_mobile() {
        return txt_mobile;
    }

    public JTextField getTxt_Name() {
        return txt_Name;
    }

    public JTextField getTxt_address() {
        return txt_address;
    }

    public JButton getEditUserBtn() {
        return editUserBtn;
    }

    public JButton getGetUserBtn() {
        return getUserBtn;
    }
}
