package View;

import javax.swing.*;
import java.awt.*;

public class FirstFrame extends JFrame {
    JButton manageUserBtn;
    JButton manageSoftwareBtn;
    JButton manageLicenseBtn;
    JPanel firstPanel;

    FirstFrame(){
        super("Main Dashboard");
        manageUserBtn = new JButton("Manage User");
        manageSoftwareBtn = new JButton("Manage Software");
        manageLicenseBtn = new JButton("Manage License");

        firstPanel = new JPanel();
        firstPanel.setLayout(new GridLayout(3,1,20,20));
        firstPanel.add(manageUserBtn);
        firstPanel.add(manageSoftwareBtn);
        firstPanel.add(manageLicenseBtn);
        add(firstPanel);
        pack();
        setSize(500,500);
        setVisible(true);
    }

    public void setFirstPanel(JPanel firstPanel) {
        this.firstPanel = firstPanel;
    }

    public void setManageUserBtn(JButton manageUserBtn) {
        this.manageUserBtn = manageUserBtn;
    }

    public void setManageSoftwareBtn(JButton manageSoftwareBtn) {
        this.manageSoftwareBtn = manageSoftwareBtn;
    }

    public void setManageLicenseBtn(JButton manageLicenseBtn) {
        this.manageLicenseBtn = manageLicenseBtn;
    }

    public JPanel getFirstPanel() {
        return firstPanel;
    }

    public JButton getManageUserBtn() {
        return manageUserBtn;
    }

    public JButton getManageSoftwareBtn() {
        return manageSoftwareBtn;
    }

    public JButton getManageLicenseBtn() {
        return manageLicenseBtn;
    }

}
