package View;
import javax.swing.*;

public class InitialPanelUser extends JPanel{
    private CenterPanelUser cpu;
    private AddPanelUser apu;
    private EditUserPanel eup;
    private DeleteUserPanel dup;
    public InitialPanelUser(){
        super();
        cpu = new CenterPanelUser();
        add(cpu);
        apu = new AddPanelUser();
        add(apu);
        eup  = new EditUserPanel();
        add(eup);
        dup = new DeleteUserPanel();
        add(dup);
    }
    public CenterPanelUser getCpu(){return cpu;}
    public EditUserPanel getEup(){return eup;}

    public DeleteUserPanel getDup(){return dup;}

    public void setEup(EditUserPanel eup) {
        this.eup = eup;
    }

    public void setDup(DeleteUserPanel dup) {
        this.dup = dup;
    }

    public void setCpu(CenterPanelUser cpu) {
        this.cpu = cpu;
    }

    public void setApu(AddPanelUser apu) {
        this.apu = apu;
    }

    public AddPanelUser getApu() {
        return apu;
    }
}
