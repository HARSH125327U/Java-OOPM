package View.License;
import javax.swing.*;
public class AddLicensePanel extends JPanel {
    JTextField txt_user_id;
    JTextField txt_app_id;
    JTextField txt_license_key;
    JTextField txt_license_cost;
    JButton addLicenseBtn;

    public AddLicensePanel(){
        txt_user_id = new JTextField();
        txt_app_id = new JTextField();
        txt_license_key = new JTextField();
        txt_license_cost = new JTextField();
        addLicenseBtn = new JButton("Add License");

        txt_user_id.setText("txt_user_id");
        txt_app_id.setText("txt_application_id");
        txt_license_key.setText("txt_license_key");
        txt_license_cost.setText("txt_license_cost");

        add(txt_user_id);
        add(txt_app_id);
        add(txt_license_key);
        add(txt_license_cost);
        add(addLicenseBtn);
    }

    public JTextField getTxt_user_id() {
        return txt_user_id;
    }

    public JTextField getTxt_license_key() {
        return txt_license_key;
    }

    public JTextField getTxt_license_cost() {
        return txt_license_cost;
    }

    public JButton getAddLicenseBtn() {
        return addLicenseBtn;
    }

    public void setTxt_user_id(JTextField txt_user_id) {
        this.txt_user_id = txt_user_id;
    }

    public void setTxt_license_key(JTextField txt_license_key) {
        this.txt_license_key = txt_license_key;
    }

    public void setTxt_license_cost(JTextField txt_license_cost) {
        this.txt_license_cost = txt_license_cost;
    }

    public void setAddLicenseBtn(JButton addLicenseBtn) {
        this.addLicenseBtn = addLicenseBtn;
    }

    public JTextField getTxt_app_id() {
        return txt_app_id;
    }

    public void setTxt_app_id(JTextField txt_app_id) {
        this.txt_app_id = txt_app_id;
    }
}
