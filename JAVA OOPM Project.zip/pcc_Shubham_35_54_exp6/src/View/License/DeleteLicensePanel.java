package View.License;

import javax.swing.*;

public class DeleteLicensePanel extends JPanel{
    JTextField txt_del_license_idx;
    JButton deleteLicenseBtn;

    public DeleteLicensePanel(){
        txt_del_license_idx = new JTextField();
        deleteLicenseBtn = new JButton("Delete License");
        txt_del_license_idx.setText("txt_license_idx");
        add(txt_del_license_idx);
        add(deleteLicenseBtn);
    }

    public void setTxt_del_license_idx(JTextField txt_del_license_idx) {
        this.txt_del_license_idx = txt_del_license_idx;
    }

    public void setDeleteLicenseBtn(JButton deleteLicenseBtn) {
        this.deleteLicenseBtn = deleteLicenseBtn;
    }

    public JTextField getTxt_del_license_idx() {
        return txt_del_license_idx;
    }

    public JButton getDeleteLicenseBtn() {
        return deleteLicenseBtn;
    }
}
