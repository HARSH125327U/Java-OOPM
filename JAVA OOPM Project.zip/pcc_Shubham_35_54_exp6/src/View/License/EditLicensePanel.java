package View.License;

import javax.swing.*;

public class EditLicensePanel extends JPanel {
    JTextField txt_get_license_idx;
    JButton getLicenseBtn;
    JTextField txt_app_id;
    JTextField txt_user_id;
    JTextField txt_license_key;
    JTextField txt_license_cost;
    JButton editLicenseBtn;

    public EditLicensePanel(){
        txt_app_id= new JTextField();
        txt_user_id = new JTextField();
        txt_license_cost = new JTextField();
        txt_license_key = new JTextField();
        txt_get_license_idx = new JTextField();
        editLicenseBtn = new JButton("Edit License");
        getLicenseBtn = new JButton("Get License to Edit");

        txt_user_id.setText("txt_user_id");
        txt_app_id.setText( "txt_app_id");
        txt_license_cost.setText("txt_license_cost");
        txt_license_key.setText("txt_license_key");
        txt_get_license_idx.setText("txt_get_license_idx");

        txt_user_id.setEditable(false); txt_app_id.setEditable(false);

        add(txt_user_id);
        add (txt_app_id);
        add(txt_license_key);
        add(txt_license_cost);
        add(editLicenseBtn);
    }

    public void setTxt_app_id(JTextField txt_app_id) {
        this.txt_app_id = txt_app_id;
    }

    public void setTxt_user_id(JTextField txt_user_id) {
        this.txt_user_id = txt_user_id;
    }

    public void setTxt_license_cost(JTextField txt_license_cost) {
        this.txt_license_cost = txt_license_cost;
    }

    public void setTxt_license_key(JTextField txt_license_key) {
        this.txt_license_key = txt_license_key;
    }

    public void setTxt_get_license_idx(JTextField txt_get_license_idx) {
        this.txt_get_license_idx = txt_get_license_idx;
    }

    public void setEditLicenseBtn(JButton editLicenseBtn) {
        this.editLicenseBtn = editLicenseBtn;
    }

    public void setGetLicenseBtn(JButton getLicenseBtn) {
        this.getLicenseBtn = getLicenseBtn;
    }


    public JTextField getTxt_app_id() {
        return txt_app_id;
    }

    public JTextField getTxt_user_id() {
        return txt_user_id;
    }

    public JTextField getTxt_license_cost() {
        return txt_license_cost;
    }

    public JTextField getTxt_license_key() {
        return txt_license_key;
    }

    public JButton getEditLicenseBtn() {
        return editLicenseBtn;
    }

    public JTextField getTxt_get_license_idx() {
        return txt_get_license_idx;
    }

    public JButton getGetLicenseBtn() {
        return getLicenseBtn;
    }
}
