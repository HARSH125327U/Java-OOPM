package View.License;
import View.License.AddLicensePanel;
import View.License.LicenseTablePanel;
import javax.swing.*;

public class InitialPanelLicense extends JPanel {
    private LicenseTablePanel ltp;
    private AddLicensePanel alp;
    private EditLicensePanel elp;
    private  DeleteLicensePanel dlp;
    public InitialPanelLicense(){
        super();
        ltp = new LicenseTablePanel();
        add(ltp);
        alp = new AddLicensePanel();
        add(alp);
        elp = new EditLicensePanel();
        add(elp);
        dlp = new DeleteLicensePanel();
        add(dlp);
    }

    public void setAlp(AddLicensePanel alp) {
        this.alp = alp;
    }

    public void setElp(EditLicensePanel elp) {
        this.elp = elp;
    }

    public void setDlp(DeleteLicensePanel dlp) {
        this.dlp = dlp;
    }

    public void setLtp(LicenseTablePanel ltp) {
        this.ltp = ltp;
    }

    public AddLicensePanel getAlp() {
        return alp;
    }

    public EditLicensePanel getElp() {
        return elp;
    }

    public DeleteLicensePanel getDlp() {
        return dlp;
    }

    public LicenseTablePanel getLtp() {
        return ltp;
    }
}
