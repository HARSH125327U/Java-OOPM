package View.License;

import View.ManageUserFrame;

import javax.swing.*;

public class ManageLicenseFrame extends JFrame {
    InitialPanelLicense license_ip;
    public ManageLicenseFrame(){
        super("Manage License Dashboard");
        license_ip = new InitialPanelLicense();
        add(license_ip);
        pack();
        setSize(500,500);
    }

    public void setLicense_ip(InitialPanelLicense license_ip) {
        this.license_ip = license_ip;
    }
    public  InitialPanelLicense getLicense_ip(){
        return license_ip;
    }
}
