package View;
import javax.swing.*;
public class ManageUserFrame extends JFrame {
    InitialPanelUser iu;
    public ManageUserFrame(){
        super("Manage User Dashboard");
        iu = new InitialPanelUser();
        add(iu);
        pack();
        setSize(500,500);
    }

    public void setIu(InitialPanelUser iu) {
        this.iu = iu;
    }

    public InitialPanelUser getIu() {
        return iu;
    }
}
