package View.Software;

import javax.swing.*;
import java.awt.*;

public class AddSoftwarePanel extends JPanel {
    JTextField txt_software_id;
    JTextField txt_software_name;
    JTextField txt_software_size;
    JTextField txt_application_id;
    JTextField txt_application_name;
    JTextField txt_application_version;
    JTextField txt_application_release_date;
    JButton addSoftwareBtn;

    public AddSoftwarePanel(){
        txt_software_id = new JTextField();
        txt_software_name = new JTextField();
        txt_software_size = new JTextField();
        txt_application_id = new JTextField();
        txt_application_name = new JTextField();
        txt_application_version = new JTextField();
        txt_application_release_date = new JTextField();
        addSoftwareBtn = new JButton("Add Software");

        txt_software_id.setText("txt_software_id");
        txt_software_name.setText("txt_software_name");
        txt_software_size.setText("txt_software_size");
        txt_application_id.setText("txt_application_id");
        txt_application_name.setText("txt_application_name");
        txt_application_version.setText("txt_application_version");
        txt_application_release_date.setText("txt_application_release_date");

        add(txt_software_id);
        add(txt_software_name);
        add(txt_software_size);
        add(txt_application_id);
        add(txt_application_name);
        add(txt_application_version);
        add(txt_application_release_date);
        add(addSoftwareBtn);
    }

    public JTextField getTxt_software_id() {
        return txt_software_id;
    }

    public JTextField getTxt_software_name() {
        return txt_software_name;
    }

    public JTextField getTxt_software_size() {
        return txt_software_size;
    }

    public JButton getAddSoftwareBtn() {
        return addSoftwareBtn;
    }

    public JTextField getTxt_application_id() {
        return txt_application_id;
    }

    public JTextField getTxt_application_name() {
        return txt_application_name;
    }

    public JTextField getTxt_application_version() {
        return txt_application_version;
    }

    public JTextField getTxt_application_release_date() {
        return txt_application_release_date;
    }

    public void setTxt_software_id(JTextField txt_software_id) {
        this.txt_software_id = txt_software_id;
    }

    public void setTxt_software_name(JTextField txt_software_name) {
        this.txt_software_name = txt_software_name;
    }

    public void setTxt_software_size(JTextField txt_software_size) {
        this.txt_software_size = txt_software_size;
    }

    public void setTxt_application_id(JTextField txt_application_id) {
        this.txt_application_id = txt_application_id;
    }

    public void setTxt_application_name(JTextField txt_application_name) {
        this.txt_application_name = txt_application_name;
    }

    public void setTxt_application_version(JTextField txt_application_version) {
        this.txt_application_version = txt_application_version;
    }

    public void setTxt_application_release_date(JTextField txt_application_release_date) {
        this.txt_application_release_date = txt_application_release_date;
    }
    public void setAddSoftwareBtn(JButton addSoftwareBtn) {
        this.addSoftwareBtn = addSoftwareBtn;
    }
}
