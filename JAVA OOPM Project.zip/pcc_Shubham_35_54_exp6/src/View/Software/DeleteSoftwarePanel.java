package View.Software;

import javax.swing.*;

public class DeleteSoftwarePanel extends JPanel {
    JTextField txt_del_software_id;
    JTextField txt_del_application_id;
    JButton deleteSoftwareBtn;

    public DeleteSoftwarePanel(){
        txt_del_software_id = new JTextField();
        txt_del_application_id = new JTextField();
        deleteSoftwareBtn = new JButton("Delete Software");

        txt_del_software_id.setText("txt_software_id");
        txt_del_application_id.setText("txt_del_application_id");
        add(txt_del_software_id);
        add(txt_del_application_id);
        add(deleteSoftwareBtn);
    }

    public void setTxt_del_software_id(JTextField txt_del_software_id) {
        this.txt_del_software_id = txt_del_software_id;
    }

    public void setTxt_del_application_id(JTextField txt_del_application_id) {
        this.txt_del_application_id = txt_del_application_id;
    }

    public void setDeleteSoftwareBtn(JButton deleteSoftwareBtn) {
        this.deleteSoftwareBtn = deleteSoftwareBtn;
    }

    public JTextField getTxt_del_software_id() {
        return txt_del_software_id;
    }

    public JTextField getTxt_del_application_id() {
        return txt_del_application_id;
    }

    public JButton getDeleteSoftwareBtn() {
        return deleteSoftwareBtn;
    }
}
