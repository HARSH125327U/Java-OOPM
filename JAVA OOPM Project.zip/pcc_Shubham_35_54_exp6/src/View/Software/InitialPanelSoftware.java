package View.Software;
import javax.swing.*;
public class InitialPanelSoftware extends JPanel{
    private SoftwareTablePanel stp;
    private AddSoftwarePanel asp;
    private EditsoftwarePanel esp;
    private DeleteSoftwarePanel dsp;

    public InitialPanelSoftware(){
        super();
        stp = new SoftwareTablePanel();
        add(stp);
        asp = new AddSoftwarePanel();
        add(asp);
        esp = new EditsoftwarePanel();
        add(esp);
        dsp = new DeleteSoftwarePanel();
        add(dsp);
    }

    public void setStp(SoftwareTablePanel stp) {
        this.stp = stp;
    }

    public void setEsp(EditsoftwarePanel esp) {
        this.esp = esp;
    }

    public void setDsp(DeleteSoftwarePanel dsp) {
        this.dsp = dsp;
    }

    public void setAsp(AddSoftwarePanel asp) {
        this.asp = asp;
    }

    public SoftwareTablePanel getStp() {
        return stp;
    }

    public EditsoftwarePanel getEsp() {
        return esp;
    }

    public AddSoftwarePanel getAsp() {
        return asp;
    }

    public DeleteSoftwarePanel getDsp() {
        return dsp;
    }
}
