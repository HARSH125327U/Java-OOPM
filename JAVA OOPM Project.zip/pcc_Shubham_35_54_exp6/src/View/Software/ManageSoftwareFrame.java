package View.Software;

import javax.swing.*;
public class ManageSoftwareFrame extends JFrame {
    InitialPanelSoftware software_ip;

    public ManageSoftwareFrame(){
        super("Manage Software Dashboard");
        software_ip = new InitialPanelSoftware();
        add(software_ip);
        pack();
        setSize(100,100);
    }

    public void setSoftware_ip(InitialPanelSoftware software_ip) {
        this.software_ip = software_ip;
    }

    public InitialPanelSoftware getSoftware_ip() {
        return software_ip;
    }
}
