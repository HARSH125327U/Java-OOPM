package View.Software;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class SoftwareTablePanel extends JPanel {
    ArrayList<JButton> software_buttons = new ArrayList<>();

    public SoftwareTablePanel()
    {
        super();
    }

    public void createButtons(int count)
    {
        for (int i = 1; i <= count; i++)
        {
            JButton b = new JButton();
            b.setBackground(Color.YELLOW);
            b.setSize(100,100);
            software_buttons.add(b);
            this.add(b);
            b.validate();
            b.repaint();
        }

    }

    public void setButtonText(int button_no, String button_text) {
        software_buttons.get(button_no).setText(button_text);
    }

    public ArrayList<JButton> getAllButtons()
    {
        return software_buttons;
    }
}
