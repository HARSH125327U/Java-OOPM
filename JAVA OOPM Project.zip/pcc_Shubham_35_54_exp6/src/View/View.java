package View;
import View.Software.ManageSoftwareFrame;
import View.License.ManageLicenseFrame;
import java.awt.*;
import java.util.ArrayList;
import java.util.Scanner;

public class View {
    FirstFrame ff;
    ManageUserFrame muf;
    ManageSoftwareFrame msof;
    ManageLicenseFrame mlf;

    public View(){
        ff = new FirstFrame();
        muf = new ManageUserFrame();
        msof = new ManageSoftwareFrame();
        mlf = new ManageLicenseFrame();
    }
    public void centerInitialSetupUser(int linesBeingDisplayed,int size){
        muf.getIu().getCpu().setLayout(new GridLayout(linesBeingDisplayed+1,size));
        muf.getIu().getCpu().createButtons((linesBeingDisplayed+1) * size);
    }
    public void centerInitialSetupSoftware(int linesBeingDisplayed, int size){
        msof.getSoftware_ip().getStp().setLayout(new GridLayout(linesBeingDisplayed+1,size));
        msof.getSoftware_ip().getStp().createButtons((linesBeingDisplayed+1) * size);
    }
    public void centerInitialSetupLicense(int linesBeingDisplayed, int size){
        mlf.getLicense_ip().getLtp().setLayout(new GridLayout(linesBeingDisplayed+1,size));
        mlf.getLicense_ip().getLtp().createButtons((linesBeingDisplayed+1)*size);
    }
    public void centerUpdateSoftware(ArrayList<ArrayList<String>> lines, ArrayList<String> headers){
        for (int i = 0; i < headers.size(); i++)
        {
            msof.getSoftware_ip().getStp().getAllButtons().get(i).setText(headers.get(i));
        }

        for (int software_row_no = 0; software_row_no < lines.size(); software_row_no++)
        {
            for (int software_col_no = 0; software_col_no < headers.size(); software_col_no++)
            {
                int button_no = software_row_no * headers.size() + headers.size() + software_col_no;
                String button_txt = lines.get(software_row_no).get(software_col_no);

                msof.getSoftware_ip().getStp().getAllButtons().get(button_no).setText(button_txt);
            }
        }
    }

    public void centerUpdateUser(ArrayList<ArrayList<String>> lines, ArrayList<String> headers){
        for (int i = 0; i < headers.size(); i++)
        {
            muf.getIu().getCpu().getAllButtons().get(i).setText(headers.get(i));
        }

        for (int user_row_no = 0; user_row_no < lines.size(); user_row_no++)
        {
            for (int user_col_no = 0; user_col_no < headers.size(); user_col_no++)
            {
                int button_no = user_row_no * headers.size() + headers.size() + user_col_no;
                String button_txt = lines.get(user_row_no).get(user_col_no);

                muf.getIu().getCpu().getAllButtons().get(button_no).setText(button_txt);
            }
        }
    }
    public void centerUpdateLicenses(ArrayList<ArrayList<String>> lines, ArrayList<String> headers) {
        for (int i = 0; i < headers.size(); i++)
        {
            mlf.getLicense_ip().getLtp().getAllButtons().get(i).setText(headers.get(i));
        }

        for (int license_row_no = 0; license_row_no < lines.size(); license_row_no++)
        {
            for (int license_col_no = 0; license_col_no < headers.size(); license_col_no++)
            {
                int button_no = license_row_no * headers.size() + headers.size() + license_col_no;
                String button_txt = lines.get(license_row_no).get(license_col_no);

                mlf.getLicense_ip().getLtp().getAllButtons().get(button_no).setText(button_txt);
            }
        }
    }

    public void setFf(FirstFrame ff) {
        this.ff = ff;
    }

    public FirstFrame getFf() {
        return ff;
    }

    public void setMuf(ManageUserFrame muf) {
        this.muf = muf;
    }

    public ManageUserFrame getMuf() {
        return muf;
    }

    public void setMsof(ManageSoftwareFrame msof) {
        this.msof = msof;
    }

    public ManageSoftwareFrame getMsof() {
        return msof;
    }

    public void setMlf(ManageLicenseFrame mlf) {
        this.mlf = mlf;
    }

    public ManageLicenseFrame getMlf() {
        return mlf;
    }
}
